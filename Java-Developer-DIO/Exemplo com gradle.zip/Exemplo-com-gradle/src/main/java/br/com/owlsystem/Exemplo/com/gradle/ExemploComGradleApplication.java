package br.com.owlsystem.Exemplo.com.gradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploComGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploComGradleApplication.class, args);
	}

}
