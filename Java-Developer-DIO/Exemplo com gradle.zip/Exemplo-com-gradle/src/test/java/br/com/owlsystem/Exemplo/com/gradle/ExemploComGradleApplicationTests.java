package br.com.owlsystem.Exemplo.com.gradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploComGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
