package br.com.owlsystem.Exemplo.com.maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploComMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
