package com.owl.system.SpringBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
